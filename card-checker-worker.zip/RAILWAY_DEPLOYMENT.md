# 🚂 دليل النشر على Railway.app

## ✨ لماذا Railway؟

- ✅ **نشر بضغطة زر** - لا يحتاج خبرة في الخوادم
- ✅ **يكتشف Docker تلقائياً** - يقرأ Dockerfile ويبني تلقائياً
- ✅ **رصيد مجاني** - $5 رصيد مجاني للبداية
- ✅ **صيانة تلقائية** - تحديثات وإعادة تشغيل تلقائية
- ✅ **HTTPS مجاني** - شهادة SSL تلقائية
- ✅ **سهل التحديث** - push إلى GitHub ويتحدث تلقائياً

---

## 📋 المتطلبات

1. ✅ حساب GitHub (مجاني)
2. ✅ حساب Railway.app (مجاني)
3. ✅ ملفات Worker Service (موجودة في مجلد `worker/`)

---

## 🚀 خطوات النشر (10 دقائق)

### **الخطوة 1: إنشاء GitHub Repository**

#### الطريقة الأولى: عبر GitHub Desktop (سهلة)
```bash
1. حمّل GitHub Desktop من: https://desktop.github.com
2. افتح البرنامج
3. اضغط File → New Repository
4. املأ:
   - Name: card-checker-worker
   - Local Path: اختر مجلد worker/
5. اضغط "Create Repository"
6. اضغط "Publish Repository"
7. اختر:
   - ✅ Keep this code private (موصى به)
   - اضغط "Publish Repository"
```

#### الطريقة الثانية: عبر سطر الأوامر
```bash
# في مجلد worker/
cd worker

# إنشاء git repository
git init
git add .
git commit -m "Initial commit: Card Checker Worker Service"

# إنشاء repo على GitHub (يحتاج GitHub CLI)
gh repo create card-checker-worker --private --source=. --remote=origin

# رفع الكود
git push -u origin main
```

#### الطريقة الثالثة: عبر موقع GitHub
```bash
1. اذهب إلى: https://github.com/new
2. املأ:
   - Repository name: card-checker-worker
   - ✅ Private
   - ❌ لا تضف README أو .gitignore
3. اضغط "Create repository"
4. اتبع التعليمات لرفع مجلد worker/
```

---

### **الخطوة 2: إنشاء حساب Railway**

```bash
1. اذهب إلى: https://railway.app
2. اضغط "Start a New Project"
3. اضغط "Login with GitHub"
4. وافق على الصلاحيات
5. ستحصل على $5 رصيد مجاني
```

---

### **الخطوة 3: نشر المشروع**

```bash
1. في Railway Dashboard، اضغط "New Project"

2. اختر "Deploy from GitHub repo"

3. اختر repository: card-checker-worker
   (إذا لم يظهر، اضغط "Configure GitHub App" وأضف الـ repo)

4. Railway سيكتشف Dockerfile تلقائياً ✅

5. انتظر البناء (3-5 دقائق)
   - سترى logs تظهر
   - انتظر حتى ترى: "Build successful"
```

---

### **الخطوة 4: إضافة Environment Variables**

```bash
1. في Railway Dashboard، اضغط على المشروع

2. اذهب إلى تبويب "Variables"

3. أضف المتغيرات التالية:

   API_KEY
   ────────────────────────────────────
   اضغط "Generate" لتوليد مفتاح عشوائي
   أو أدخل مفتاحك الخاص (32+ حرف)
   مثال: sk_live_abc123xyz789def456ghi012jkl345

   PORT
   ────────────────────────────────────
   5000

   RATE_LIMIT_PER_HOUR (اختياري)
   ────────────────────────────────────
   100

   ENABLE_IP_WHITELIST (اختياري)
   ────────────────────────────────────
   false

4. اضغط "Add" لكل متغير

5. Railway سيعيد النشر تلقائياً
```

---

### **الخطوة 5: الحصول على Public URL**

```bash
1. في Railway Dashboard، اذهب إلى تبويب "Settings"

2. ابحث عن قسم "Networking"

3. اضغط "Generate Domain"

4. سيظهر URL مثل:
   https://card-checker-worker-production.up.railway.app

5. انسخ هذا الـ URL ✅
```

---

### **الخطوة 6: اختبار الخدمة**

```bash
# استبدل YOUR_URL و YOUR_API_KEY
curl -X POST https://your-project.up.railway.app/api/health \
  -H "X-API-Key: your-api-key-here"

# يجب أن يرجع:
{
  "status": "healthy",
  "timestamp": "2026-01-31T12:00:00.000Z",
  "version": "1.0.0"
}
```

---

### **الخطوة 7: ربط مع Airo**

```bash
1. في Airo، اذهب إلى Settings → Secrets

2. أضف Secret جديد:
   Name: WORKER_SERVICE_URL
   Value: https://your-project.up.railway.app

3. أضف Secret آخر:
   Name: WORKER_API_KEY
   Value: نفس API_KEY من Railway

4. احفظ التغييرات

5. اختبر من صفحة الفحص المتقدم في Airo
```

---

## 🧪 اختبار كامل

### **1. اختبار Health Check**
```bash
curl -X POST https://your-project.up.railway.app/api/health \
  -H "X-API-Key: your-api-key"
```

### **2. اختبار فحص بطاقة واحدة**
```bash
curl -X POST https://your-project.up.railway.app/api/check-card \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "card_number": "4532015112830366",
    "expiry_month": "12",
    "expiry_year": "2025",
    "cvv": "123",
    "site": "loft"
  }'
```

### **3. اختبار من Airo**
```bash
1. افتح صفحة الفحص المتقدم في Airo
2. اختر "فحص متقدم"
3. اختر موقع (LOFT أو Ann Taylor)
4. أدخل بيانات بطاقة تجريبية:
   - Card: 4532015112830366
   - Expiry: 12/2025
   - CVV: 123
5. اضغط "فحص البطاقة"
6. انتظر 30-60 ثانية
7. يجب أن ترى النتيجة
```

---

## 📊 مراقبة الخدمة

### **عرض Logs**
```bash
1. في Railway Dashboard
2. اضغط على المشروع
3. اذهب إلى تبويب "Deployments"
4. اضغط على آخر deployment
5. اضغط "View Logs"
6. سترى logs مباشرة
```

### **مراقبة الأداء**
```bash
1. في Railway Dashboard
2. اذهب إلى تبويب "Metrics"
3. سترى:
   - CPU Usage
   - Memory Usage
   - Network Traffic
   - Request Count
```

### **إعادة التشغيل**
```bash
1. في Railway Dashboard
2. اضغط على المشروع
3. اضغط على "..." (ثلاث نقاط)
4. اختر "Restart"
```

---

## 💰 التكلفة

### **الخطة المجانية**
- ✅ $5 رصيد مجاني
- ✅ 500 ساعة تشغيل/شهر
- ✅ كافي للاختبار والتطوير

### **الخطة المدفوعة**
- 💳 $5/شهر للبداية
- 💳 تدفع فقط مقابل الاستخدام
- 💳 حوالي $0.000231/دقيقة

### **تقدير التكلفة**
```bash
الاستخدام المتوسط:
- 100 فحص/يوم
- كل فحص = 1 دقيقة
- 100 دقيقة/يوم = 3000 دقيقة/شهر
- التكلفة = 3000 × $0.000231 = ~$0.70/شهر

الاستخدام الكثيف:
- 500 فحص/يوم
- 500 دقيقة/يوم = 15000 دقيقة/شهر
- التكلفة = 15000 × $0.000231 = ~$3.50/شهر
```

---

## 🔄 التحديثات

### **تحديث الكود**
```bash
# في مجلد worker/ على جهازك

1. عدّل الملفات

2. احفظ التغييرات:
   git add .
   git commit -m "Update: description of changes"
   git push

3. Railway سيكتشف التغييرات تلقائياً

4. سيبني ويعيد النشر تلقائياً (3-5 دقائق)

5. تحقق من Logs للتأكد من نجاح النشر
```

### **تحديث Environment Variables**
```bash
1. في Railway Dashboard
2. اذهب إلى "Variables"
3. عدّل القيمة
4. اضغط "Update"
5. Railway سيعيد التشغيل تلقائياً
```

---

## 🔒 الأمان

### **حماية API Key**
```bash
✅ استخدم مفتاح قوي (32+ حرف عشوائي)
✅ لا تشارك المفتاح في الكود
✅ غيّر المفتاح بانتظام (كل 3-6 أشهر)
✅ استخدم مفاتيح مختلفة للتطوير والإنتاج
```

### **تفعيل IP Whitelist (اختياري)**
```bash
1. في Railway Variables، أضف:
   ENABLE_IP_WHITELIST=true
   ALLOWED_IPS=1.2.3.4,5.6.7.8

2. احصل على IP الخاص بـ Airo:
   curl https://api.ipify.org

3. أضف IP إلى ALLOWED_IPS

4. الآن فقط Airo يمكنه الوصول للخدمة
```

### **HTTPS فقط**
```bash
✅ Railway يوفر HTTPS تلقائياً
✅ لا تستخدم HTTP أبداً
✅ تحقق من أن URL يبدأ بـ https://
```

---

## 🐛 حل المشاكل

### **المشكلة: Build Failed**
```bash
الحل:
1. تحقق من Logs في Railway
2. تأكد من وجود Dockerfile في المجلد الرئيسي
3. تأكد من requirements.txt صحيح
4. جرب إعادة النشر: Settings → Redeploy
```

### **المشكلة: Service Crashed**
```bash
الحل:
1. تحقق من Logs
2. تأكد من PORT=5000 في Variables
3. تأكد من API_KEY موجود
4. أعد التشغيل: Restart
```

### **المشكلة: 401 Unauthorized**
```bash
الحل:
1. تحقق من API_KEY في Railway
2. تحقق من WORKER_API_KEY في Airo
3. تأكد من أنهما متطابقان تماماً
4. لا مسافات زائدة في البداية أو النهاية
```

### **المشكلة: Timeout**
```bash
الحل:
1. الفحص يأخذ 30-60 ثانية (طبيعي)
2. تحقق من أن الخدمة تعمل: /api/health
3. تحقق من Metrics في Railway
4. إذا كان CPU/Memory عالي، قد تحتاج upgrade
```

### **المشكلة: Playwright Error**
```bash
الحل:
1. تحقق من Logs
2. تأكد من أن Dockerfile يثبت Chromium:
   RUN playwright install chromium
   RUN playwright install-deps
3. أعد البناء: Settings → Redeploy
```

---

## 📈 تحسين الأداء

### **1. استخدام Proxies**
```bash
1. أضف ملف proxies.txt في المجلد
2. املأه بـ proxies (سطر واحد لكل proxy):
   http://user:pass@proxy1.com:8080
   http://user:pass@proxy2.com:8080
3. push إلى GitHub
4. Railway سيحدث تلقائياً
```

### **2. زيادة Rate Limit**
```bash
1. في Railway Variables
2. عدّل RATE_LIMIT_PER_HOUR
3. مثال: 200 (بدلاً من 100)
4. احفظ
```

### **3. Upgrade الخطة**
```bash
إذا كان الاستخدام عالي:
1. في Railway Dashboard
2. اذهب إلى Settings → Plan
3. اختر خطة أعلى
4. ستحصل على:
   - CPU أسرع
   - Memory أكثر
   - Network أسرع
```

---

## 📚 موارد إضافية

### **التوثيق**
- [Railway Docs](https://docs.railway.app)
- [Playwright Docs](https://playwright.dev)
- [Flask Docs](https://flask.palletsprojects.com)

### **الدعم**
- [Railway Discord](https://discord.gg/railway)
- [Railway Community](https://community.railway.app)

### **ملفات المشروع**
- `WORKER_SETUP.md` - دليل الإعداد الكامل
- `QUICKSTART.md` - بدء سريع
- `README.md` - نظرة عامة
- `CHECK_SYSTEM.md` - دليل الفحص اليدوي

---

## ✅ Checklist النشر

```bash
☐ إنشاء GitHub repository
☐ رفع ملفات worker/ إلى GitHub
☐ إنشاء حساب Railway
☐ ربط GitHub مع Railway
☐ نشر المشروع
☐ إضافة Environment Variables (API_KEY, PORT)
☐ توليد Public Domain
☐ اختبار /api/health
☐ إضافة WORKER_SERVICE_URL إلى Airo
☐ إضافة WORKER_API_KEY إلى Airo
☐ اختبار فحص بطاقة من Airo
☐ مراقبة Logs
☐ تفعيل IP Whitelist (اختياري)
☐ إضافة Proxies (اختياري)
```

---

## 🎉 تم بنجاح!

الآن لديك Worker Service يعمل على Railway.app:

✅ **نشر تلقائي** - push إلى GitHub ويتحدث تلقائياً
✅ **HTTPS مجاني** - شهادة SSL تلقائية
✅ **مراقبة مباشرة** - Logs و Metrics
✅ **صيانة تلقائية** - تحديثات وإعادة تشغيل
✅ **سهل التوسع** - upgrade بضغطة زر

**التكلفة المتوقعة:** $0.70 - $3.50/شهر (حسب الاستخدام)

---

**تاريخ التحديث:** 2026-01-31  
**الحالة:** ✅ جاهز للنشر  
**المدة المتوقعة:** 10-15 دقيقة
